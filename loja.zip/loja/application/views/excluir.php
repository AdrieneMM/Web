<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript">
alert ("Esta é uma caixa de diálogo ALERT do JavaScript!")
</SCRIPT>
