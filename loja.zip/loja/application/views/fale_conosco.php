<div id="homebody">
    <div class="alinhado-centro borda-base espaco-vertical">
        <h3>Fale Conosco.</h3>
        <p>Use o formulário abaixo para  enviar um e-mail para nos.</p>
    </div>
     <div class="row-fluid">
    <?php
        echo form_open(base_url('cadastro/email_fale_conosco'), array('id'=>'fale_conosco')) .
        form_label("Nome:") . "<br>" .
        form_input(array('id'=>'nome1','name'=>'nome1')) . "<br>" . "<br>" .
        form_label("Mensagem:",'texto') . "<br>" .
        form_textarea('texto') . "<br>" . "<br>" .
        form_submit("btnFalar","Enviar") .
        form_close()
    ?>
    </div>
</div>
