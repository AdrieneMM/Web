<div id="homebody">
    <div class="alinhado-centro borda-base espaco-vertical">
        <h3>Seja Bem-Vindo à área de administração. </h3>
        <p>Aqui você poderá Incluir, Alterar ou  Excluir registros nas tabelas de categorias, produtos ou frete</p>

    </div>
    <div class="row-fluid" >
        <a id="bot1" class="btn btn-medium btn-primary" href="<?php echo base_url("cade")?>">Cadastro de categorias</a>
        <a id="bot2"class="btn btn-medium btn-primary" href="#">Cadastro de produtos</a>
        <a id="bot3"class="btn btn-medium btn-primary" href="#">Tabela de fretes</a>
    </div>
</div>
