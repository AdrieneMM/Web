<!DOCTYPE html>
    <html>
        <head>
            <meta charset="utf-8">
            <title>Lojão do Terceirão</title>
        </head>
        <body>
            <h2> Lojão do Terceirão</h2>
            <h3> Novo email do fale-conosco</h3>
            <p> Nome: <?php echo $nome ?></p> <br> <br>
            <p> <?php echo $texto ?></p>
        </body>
    </html>
