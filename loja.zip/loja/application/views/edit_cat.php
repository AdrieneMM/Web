<div id="homebody">

     <div class="row-fluid">
  
    <div class="table-responsive">
        <?php
        		$atributos = array('name'=>'formuario_categoria','id'=>'formulario__categoria') ;

            echo "<table id='mytable' class='table table-bordred table-striped'><thead><th>Titulo</th><th>Descrição</th></thead><tbody>";
         
            echo "<tr><td>".form_open( base_url('sal_edit/salvar_alteracao/'),$atributos).form_hidden('id', $categorias[0]->id).form_input('txt_titulo',$categorias[0]->titulo)."<br>"."</td><td>".form_input('txt_des',$categorias[0]->descricao)."<br>". 
            		"<br>" . "<br>" ."</td></tr>";
         	
            echo "</tbody></table>";
            echo form_submit("btnFalar","Salvar Alterações") .
           		form_close();
           		
          		
        ?>



    </div>
    </div>
</div>


