<div id="homebody">
    <div class="alinhado-centro borda-base espaco-vertical">
        <h3> Categorias </h3>

    </div>
     <div class="row-fluid">
    <div class="table-responsive">
        <?php
            echo "<table id='mytable' class='table table-bordred table-striped'><thead><th>Titulo</th><th>Descrição</th><th>Operações</th></thead><tbody>";
                foreach($categorias as $id) {
                echo "<tr><td>".$id->titulo."</td><td>".$id->descricao."</td><td>".anchor(base_url("contr_edit/index/".$id->id),"Editar",array("class"=>"btn btn-warning"))." ".anchor(base_url("contr_edit/ex/".$id->id),"Excluir",array("class"=>"btn btn-danger"))."</td></tr>";
            }
   
            echo "</tbody></table>";
            echo anchor(base_url("sal_edit/novoadd/".$id->id),"Novo item",array("class"=>"btn btn-primary"));
        ?>


    </div>
</div>
</div>

