<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
    class Sal_edit extends CI_Controller{
       public $categorias;

       public function __construct(){
            parent::__construct();
            $this->load->model('categorias_model','modelcategorias');
            $this->load->model('produtos_model','modelprodutos');
            $this->categorias = $this->modelcategorias->listar_categorias();
        }

        public function alterar($id){
            $this->db->where('id',$id);
            $dados['categorias'] = $this->db->get('categorias')->result();
                $this->load->helper('form');
            $this->load->view('html-header');
            $this->load->view('admin_menu');
            $this->load->view('edit_cat',$dados);
            $this->load->view('footer');
            $this->load->view('html-footer');
        }
    public function salvar_alteracao(){
        $dados['titulo']=$this->input->post('txt_titulo');
        $dados['descricao']=$this->input->post('txt_des');
        $this->db->where('id',$this->input->post('id'));
        if($this->db->update('categorias',$dados)){
            redirect(base_url('cade'));
        }else{
            echo "Não foi possível gravar a alteração da postagem no banco de dados";
        }
    }

		public function adicionar(){
        $dados['titulo']=$this->input->post('txt_titulo');
        $dados['descricao']=$this->input->post('txt_des');
        if($this->db->insert('categorias',$dados)){
            redirect(base_url('cade'));
        }else{
            echo "Não foi possível gravar a alteração da postagem no banco de dados";
        }
    }
    
     public function novoadd(){

            $dados['categorias'] = $this->db->get('categorias')->result();
                $this->load->helper('form');
            $this->load->view('html-header');
            $this->load->view('admin_menu');
            $this->load->view('novo_cat',$dados);
            $this->load->view('footer');
            $this->load->view('html-footer');
        }

    }
