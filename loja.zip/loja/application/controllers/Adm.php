<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
    class Adm extends CI_Controller{
       public $categorias;

      /*  public function __construct(){
            parent::__construct();
            $this->load->model('categorias_model','modelcategorias');
            $this->load->model('produtos_model','modelprodutos');
            $this->categorias = $this->modelcategorias->listar_categorias();
        }*/

        public function index(){
            $this->load->helper('text');
            $this->load->view('html-header');
            $this->load->view('admin_menu');
            $this->load->view('admin');
            $this->load->view('footer');
            $this->load->view('html-footer');
        }


    }
