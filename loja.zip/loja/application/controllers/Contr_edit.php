<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
    class Contr_edit extends CI_Controller{
       public $categorias;

       public function __construct(){
            parent::__construct();
            $this->load->model('categorias_model','modelcategorias');
            $this->load->model('produtos_model','modelprodutos');
            $this->categorias = $this->modelcategorias->listar_categorias();
        }

        public function index($id){
        	$this->db->where('id',$id);
        	$dados['categorias'] = $this->db->get('categorias')->result();			
 				$this->load->helper('form');
            $this->load->view('html-header');
            $this->load->view('admin_menu');
            $this->load->view('edit_cat',$dados);
            $this->load->view('footer');
            $this->load->view('html-footer');
        }
       
        public function ex($id){
        	$this->db->where('id',$id);
        	$dados['categorias'] = $this->db->get('categorias')->result();			
 				$this->load->helper('form');
            $this->load->view('html-header');
            $this->load->view('admin_menu');
            $this->load->view('excluir',$dados);
            $this->load->view('footer');
            $this->load->view('html-footer');
        }


    }
